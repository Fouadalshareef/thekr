/* =====================================================================
   Game UI Buttons — تفاعل الأزرار (نقرة + موجة + صوت اختياري + عمق)
   ===================================================================== */
(function () {
  "use strict";

  var buttons = document.querySelectorAll(".gbtn");
  var toastText = document.getElementById("toast-text");
  var dot = document.querySelector(".panel__dot");
  var soundToggle = document.getElementById("sound-toggle");
  var depthToggle = document.getElementById("depth-toggle");
  var copyBtn = document.getElementById("copy-btn");
  var snippet = document.getElementById("code-snippet");
  var audioCtx = null;

  /* --- نغمة نقرة قصيرة عبر Web Audio (بدون ملفات صوت) --- */
  function clickTone(freq) {
    try {
      if (!audioCtx) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        audioCtx = new AC();
      }
      var t = audioCtx.currentTime;
      var osc = audioCtx.createOscillator();
      var gain = audioCtx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.6, t + 0.12);
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.16, t + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start(t);
      osc.stop(t + 0.18);
    } catch (e) { /* تجاهل أي خطأ صوتي */ }
  }

  function toast(msg, color) {
    if (toastText) toastText.textContent = msg;
    if (dot) {
      dot.style.background = color || "#6fe3a1";
      dot.style.boxShadow = "0 0 0 4px " + hexA(color || "#6fe3a1", 0.18) +
                            ", 0 0 14px " + (color || "#6fe3a1");
    }
  }

  function hexA(hex, a) {
    var h = hex.replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + a + ")";
  }

  /* لون توهّج كل نمط (للتقرير النصي فقط) */
  var themeColors = {
    steel: "#6f9dff",
    sunset: "#ff8a4c",
    leaf: "#77e06e",
    gold: "#ffd577",
    coral: "#ff7ea0"
  };

  var toneMap = { steel: 520, sunset: 660, leaf: 600, gold: 740, coral: 460 };

  /* --- ربط التفاعل بكل زر --- */
  Array.prototype.forEach.call(buttons, function (btn) {
    var theme = btn.getAttribute("data-theme") || "steel";

    btn.addEventListener("click", function () {
      var name = btn.getAttribute("data-name") || "زر";
      var color = themeColors[theme] || "#6f9dff";

      /* موجة نقرية حول الزر */
      btn.classList.remove("is-pulsing");
      void btn.offsetWidth; /* إعادة تشغيل الحركة */
      btn.classList.add("is-pulsing");

      /* قفزة ممتعة */
      btn.classList.remove("is-clicked");
      void btn.offsetWidth;
      btn.classList.add("is-clicked");

      if (soundToggle && soundToggle.checked) clickTone(toneMap[theme] || 520);

      toast("تم الضغط على: " + name, color);
    });

    btn.addEventListener("animationend", function (e) {
      if (e.animationName === "gbtn-pulse") btn.classList.remove("is-pulsing");
      if (e.animationName === "gbtn-pop") btn.classList.remove("is-clicked");
    });
  });

  /* --- تبديل عمق الإطار --- */
  if (depthToggle) {
    depthToggle.addEventListener("click", function () {
      var flat = document.body.classList.toggle("flat");
      depthToggle.textContent = flat ? "عمق الإطار: منخفض" : "عمق الإطار: مرتفع";
    });
  }

  /* --- نسخ كود الزر --- */
  if (copyBtn && snippet) {
    copyBtn.addEventListener("click", function () {
      var text = snippet.textContent;
      var done = function () {
        copyBtn.textContent = "تم النسخ ✓";
        setTimeout(function () { copyBtn.textContent = "نسخ HTML"; }, 1600);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text, done); });
      } else {
        fallbackCopy(text, done);
      }
    });
  }

  function fallbackCopy(text, done) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); done(); } catch (e) { /* لا شيء */ }
    document.body.removeChild(ta);
  }
})();
